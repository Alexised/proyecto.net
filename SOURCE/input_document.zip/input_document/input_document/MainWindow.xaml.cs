﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using SautinSoft.Document;

namespace input_document
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        string filePath = string.Empty;
        string savePath = string.Empty;
        string contenido = string.Empty;
        ClassDocument docIndentifcator;


        public MainWindow()
        {
            InitializeComponent();

        }

        public void tbx_fincas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9) ; // it`s number
            else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) ; // it`s number
            else if (e.Key == Key.Escape || e.Key == Key.Tab || e.Key == Key.CapsLock || e.Key == Key.LeftShift || e.Key == Key.LeftCtrl ||
                e.Key == Key.LWin || e.Key == Key.LeftAlt || e.Key == Key.RightAlt || e.Key == Key.RightCtrl || e.Key == Key.RightShift ||
                e.Key == Key.Left || e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.Right || e.Key == Key.Return || e.Key == Key.Delete ||
                e.Key == Key.System) ; // it`s a system key (add other key here if you want to allow)
            else
                e.Handled = true; // the key will sappressed
        }

        public void tbx_folio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9) ; // it`s number
            else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) ; // it`s number
            else if (e.Key == Key.Escape || e.Key == Key.Tab || e.Key == Key.CapsLock || e.Key == Key.LeftShift || e.Key == Key.LeftCtrl ||
                e.Key == Key.LWin || e.Key == Key.LeftAlt || e.Key == Key.RightAlt || e.Key == Key.RightCtrl || e.Key == Key.RightShift ||
                e.Key == Key.Left || e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.Right || e.Key == Key.Return || e.Key == Key.Delete ||
                e.Key == Key.System) ; // it`s a system key (add other key here if you want to allow)
            else
                e.Handled = true; // the key will sappressed
        }

        public void tbx_vendedor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.A && e.Key <= Key.Z) ; // it`s words
            else if (e.Key == Key.Escape || e.Key == Key.Tab || e.Key == Key.CapsLock || e.Key == Key.LeftShift || e.Key == Key.LeftCtrl ||
                e.Key == Key.LWin || e.Key == Key.LeftAlt || e.Key == Key.RightAlt || e.Key == Key.RightCtrl || e.Key == Key.RightShift ||
                e.Key == Key.Left || e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.Right || e.Key == Key.Return || e.Key == Key.Delete ||
                e.Key == Key.System) ; // it`s a system key (add other key here if you want to allow)
            else
                e.Handled = true; // the key will sappressed
        }

        public void tbx_comprador_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.A && e.Key <= Key.Z) ; // it`s words
            else if (e.Key == Key.Escape || e.Key == Key.Tab || e.Key == Key.CapsLock || e.Key == Key.LeftShift || e.Key == Key.LeftCtrl ||
                e.Key == Key.LWin || e.Key == Key.LeftAlt || e.Key == Key.RightAlt || e.Key == Key.RightCtrl || e.Key == Key.RightShift ||
                e.Key == Key.Left || e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.Right || e.Key == Key.Return || e.Key == Key.Delete ||
                e.Key == Key.System) ; // it`s a system key (add other key here if you want to allow)
            else
                e.Handled = true; // the key will sappressed
        }

        public void btn_upload_Click(object sender, RoutedEventArgs e)
        {

            string vendedor = tbx_vendedor.Text;
            string nrofincas = tbx_fincas.Text;
            string nrofolios = tbx_folio.Text;
            string comprador = tbx_comprador.Text;


            Stream myStream;
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.InitialDirectory = @"C:\";
            saveFileDialog.Filter = "doc files (*.doc)|*.doc";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() != DialogResult)
            {
                savePath = saveFileDialog.FileName;

                if ((myStream = saveFileDialog.OpenFile()) != null)
                {
                    myStream.Close();

                    DocumentCore dc = new DocumentCore();

                    dc.Content.End.Insert("<" + vendedor
                                                + ">" + ", \" vende <"
                                                + nrofincas + "> finca<s si hay mas que uno> de terreno  conocido<s si hay mas que uno> como Finca o Folio Real No. <"
                                                + nrofolios + "> <si hay mas que una finca entonces  “ y Finca o Folio Real No. <finca2numero>” a <"
                                                + comprador + ">.");

                    dc.Save(savePath, new DocxSaveOptions());

                    Environment.Exit(0);

                    
                }
            }

        }

        public void btn_loadFiles_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = @"C:\";
            openFileDialog.Filter = "doc files (*.doc)|*.doc";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() != DialogResult)
            {
                //Get the path of specified file
                filePath = openFileDialog.FileName;

                DocumentCore dc = DocumentCore.Load(filePath);
                contenido = dc.Content.ToString();

                if (contenido != null)
                {
                    char[] delimiters = new char[] { '<', '>' };
                    string[] parts = contenido.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                    docIndentifcator = new ClassDocument();

                    docIndentifcator.comprador = parts[0];
                    docIndentifcator.nrofinca = parts[2];
                    docIndentifcator.nrofolio = parts[8];
                    docIndentifcator.vendedor = parts[13];

                    tbx_vendedor.Text = parts[0];
                    tbx_fincas.Text =parts[2]; 
                    tbx_folio.Text= parts[8];
                    tbx_comprador.Text = parts[13];

                }

            }

        }

    }
}
