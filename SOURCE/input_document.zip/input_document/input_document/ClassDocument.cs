﻿namespace input_document
{
    public class ClassDocument
    {
        public string vendedor { get; set; }
        public string nrofinca { get; set; }
        public string nrofolio { get; set; }
        public string comprador { get; set; }
    }
}